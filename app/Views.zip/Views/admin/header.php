<header class="app-header">
    <nav class="navbar navbar-expand-lg navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item d-block d-xl-none">
                <a class="nav-link sidebartoggler " id="headerCollapse" href="javascript:void(0)">
                    <i class="ti ti-menu-2"></i>
                </a>
            </li>
            <!--
                        <li class="nav-item dropdown">
                            <a class="nav-link " href="javascript:void(0)" id="drop1" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <i class="ti ti-bell"></i>
                                <div class="notification bg-primary rounded-circle"></div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-animate-up" aria-labelledby="drop1">
                                <div class="message-body">
                                    <a href="javascript:void(0)" class="dropdown-item">
                                        Item 1
                                    </a>
                                    <a href="javascript:void(0)" class="dropdown-item">
                                        Item 2
                                    </a>
                                </div>
                            </div>
                        </li> -->
        </ul>
        <div class="navbar-collapse justify-content-end px-0" id="navbarNav">
            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">
                <li>
                    <div class="position-relative">
                        <form class="position-relative" action="<?= site_url('admin/customer-search') ?>" method="GET">
                            <input type="text" class="form-control product-search ps-5" id="customerSearch" name="keyword" autocomplete="off" placeholder="Search Customer, Policy, Vehicle">
                            <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y fs-6 text-dark ms-3"></i>
                        </form>
                        <!--
                        <form action="<?= site_url('admin/customer-search') ?>" method="GET">

                            <div class="input-group">

                                <span class="input-group-text">
                                    <i class="ti ti-search"></i>
                                </span>

                                <input type="text" id="customerSearch" name="keyword" class="form-control"
                                    autocomplete="off" placeholder="Search Customer, Policy, Vehicle">
                                


                            </div>

                        </form>-->

                        <div id="suggestionBox" class="list-group shadow"
                            style="position:absolute; width:100%; z-index:999; display:none;">
                        </div>

                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link " href="javascript:void(0)" id="drop1" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <div class="d-flex align-items-center gap-2 border-start ps-3">
                            <div class="user-profile-img">
                                <?php
                                    $photo = session()->get('profilePhoto');
                                    if (empty($photo)) {
                                                // normalize gender to lowercase
                                        $gender = strtolower(session()->get('gender'));
                                        // fallback based on gender
                                        $photo = ($gender === 'male') ? 'user-1.jpg' : 'user-2.jpg';
                                    }
                                ?>
                                <img src="<?= base_url('uploads/profile/' . $photo) ?>" class="rounded-circle"
                                    width="35" height="35" alt="profile-img">
                            </div>
                            <div class="d-none d-md-flex align-items-center">
                                <h5 class="mb-0 fs-4">Hi,</h5>
                                <h5 class="mb-0 fs-4 fw-semibold ms-1">
                                    &nbsp;<?= esc(explode(' ', session()->get('employeeName'))[0]) ?> &nbsp;</h5>
                                <i class="ti ti-chevron-down"></i>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop2">
                        <div class="message-body">

                            <a href="<?= base_url('admin/employee/' . session()->get('employeeId')) ?>"
                                class="d-flex align-items-center gap-2 dropdown-item">
                                <i class="ti ti-user fs-6"></i>
                                <p class="mb-0 fs-3">My Profile</p>
                            </a>
                            <!--
                                        <a href="javascript:void(0)"
                                            class="d-flex align-items-center gap-2 dropdown-item">
                                            <i class="ti ti-mail fs-6"></i>
                                            <p class="mb-0 fs-3">My Account</p>
                                        </a>
                                        <a href="javascript:void(0)"
                                            class="d-flex align-items-center gap-2 dropdown-item">
                                            <i class="ti ti-list-check fs-6"></i>
                                            <p class="mb-0 fs-3">My Task</p>
                                        </a> -->
                            <a href="<?= base_url('/employee/logout') ?>"
                                class="btn btn-outline-primary mx-3 mt-2 d-block">Logout</a>
                        </div>
                    </div>
                </li>


            </ul>
        </div>
    </nav>
</header>